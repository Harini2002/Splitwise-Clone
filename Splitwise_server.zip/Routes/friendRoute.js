// import express from "express";
// import { getFriend } from "../Controllers/friendsController";


// const router = express.Router();
// router.route('/getfriends').post(getFriend)

// export default router;
